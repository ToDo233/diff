package com.zl.mjga.dto.urp;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserQueryDto {
  private String username;
}
