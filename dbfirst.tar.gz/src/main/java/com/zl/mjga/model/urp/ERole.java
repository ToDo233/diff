package com.zl.mjga.model.urp;

public enum ERole {
  ADMIN,
  GENERAL
}
