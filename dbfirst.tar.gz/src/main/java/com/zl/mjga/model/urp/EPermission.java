package com.zl.mjga.model.urp;

public enum EPermission {
  WRITE_USER_ROLE_PERMISSION,
  READ_USER_ROLE_PERMISSION
}
